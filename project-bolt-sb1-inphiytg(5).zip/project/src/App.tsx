import React, { useState } from 'react';
import { Shield, Car, Heart, Home, Phone, Mail, MapPin, Star, Users, Award, CheckCircle, ArrowRight, Menu, X, ChevronDown, Clock, Calculator, FileText, Headphones } from 'lucide-react';

function App() {
  const [selectedInsurance, setSelectedInsurance] = useState('health');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [showQuoteForm, setShowQuoteForm] = useState(false);

  const insuranceTypes = [
    { id: 'health', name: 'Health Insurance', icon: Heart, color: 'from-emerald-500 to-teal-600' },
    { id: 'car', name: 'Motor Insurance', icon: Car, color: 'from-blue-500 to-indigo-600' },
    { id: 'home', name: 'Home Insurance', icon: Home, color: 'from-green-500 to-emerald-600' },
    { id: 'life', name: 'Life Insurance', icon: Shield, color: 'from-purple-500 to-blue-600' },
  ];

  const healthPlans = [
    {
      id: 1,
      name: 'Star Health Premier',
      provider: 'Star Health',
      premium: '₹8,500',
      coverage: '₹5,00,000',
      features: ['Cashless Treatment', 'Pre & Post Hospitalization', 'Day Care Procedures', 'Ambulance Cover'],
      rating: 4.5,
      popular: true,
      discount: '15% OFF'
    },
    {
      id: 2,
      name: 'HDFC ERGO My Health',
      provider: 'HDFC ERGO',
      premium: '₹9,200',
      coverage: '₹5,00,000',
      features: ['Wellness Benefits', 'Mental Health Cover', 'Maternity Benefits', 'Critical Illness'],
      rating: 4.3,
      popular: false,
      discount: '10% OFF'
    },
    {
      id: 3,
      name: 'Bajaj Allianz Health Guard',
      provider: 'Bajaj Allianz',
      premium: '₹7,800',
      coverage: '₹5,00,000',
      features: ['No Room Rent Limit', 'Organ Donor Cover', 'Second Opinion', 'Home Treatment'],
      rating: 4.2,
      popular: false,
      discount: '12% OFF'
    }
  ];

  const features = [
    {
      icon: Calculator,
      title: 'Smart Comparison',
      description: 'Compare 45+ insurers instantly with our AI-powered comparison engine'
    },
    {
      icon: Clock,
      title: 'Instant Quotes',
      description: 'Get personalized quotes in under 30 seconds with zero paperwork'
    },
    {
      icon: Shield,
      title: 'Secure & Trusted',
      description: 'Bank-grade security with 50L+ happy customers and ₹1000Cr+ claims settled'
    },
    {
      icon: Headphones,
      title: '24/7 Support',
      description: 'Expert guidance from certified insurance advisors whenever you need'
    }
  ];

  const testimonials = [
    {
      name: 'Priya Sharma',
      location: 'Mumbai',
      text: 'Saved ₹12,000 on my family health insurance. The comparison was so easy and transparent.',
      rating: 5,
      avatar: 'https://images.pexels.com/photos/1130626/pexels-photo-1130626.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop',
      plan: 'Health Insurance'
    },
    {
      name: 'Rajesh Kumar',
      location: 'Delhi',
      text: 'Found the perfect car insurance with comprehensive coverage at 40% less premium.',
      rating: 5,
      avatar: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop',
      plan: 'Motor Insurance'
    },
    {
      name: 'Anita Patel',
      location: 'Bangalore',
      text: 'Excellent service! Got my term life insurance approved within 24 hours.',
      rating: 5,
      avatar: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&fit=crop',
      plan: 'Life Insurance'
    }
  ];

  const QuoteForm = () => (
    <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-3xl p-8 max-w-md w-full max-h-[90vh] overflow-y-auto shadow-2xl">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h3 className="text-2xl font-bold text-gray-900">Get Free Quote</h3>
            <p className="text-gray-600 text-sm mt-1">Compare plans from 45+ insurers</p>
          </div>
          <button
            onClick={() => setShowQuoteForm(false)}
            className="text-gray-400 hover:text-gray-600 transition-colors p-2"
          >
            <X size={24} />
          </button>
        </div>
        
        <form className="space-y-5">
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">Full Name *</label>
            <input
              type="text"
              className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-teal-500 focus:border-transparent transition-all bg-gray-50 focus:bg-white"
              placeholder="Enter your full name"
            />
          </div>
          
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">Mobile Number *</label>
            <input
              type="tel"
              className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-teal-500 focus:border-transparent transition-all bg-gray-50 focus:bg-white"
              placeholder="+91 Enter mobile number"
            />
          </div>
          
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">Email Address</label>
            <input
              type="email"
              className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-teal-500 focus:border-transparent transition-all bg-gray-50 focus:bg-white"
              placeholder="Enter your email address"
            />
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">Age *</label>
              <select className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-teal-500 focus:border-transparent transition-all bg-gray-50 focus:bg-white">
                <option>Select age</option>
                <option>18-25</option>
                <option>26-35</option>
                <option>36-45</option>
                <option>46-55</option>
                <option>56+</option>
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">City *</label>
              <input
                type="text"
                className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-teal-500 focus:border-transparent transition-all bg-gray-50 focus:bg-white"
                placeholder="Your city"
              />
            </div>
          </div>
          
          <button
            type="submit"
            className="w-full bg-gradient-to-r from-teal-500 to-blue-600 text-white py-4 px-6 rounded-xl font-semibold hover:from-teal-600 hover:to-blue-700 transform hover:scale-[1.02] transition-all duration-200 shadow-lg hover:shadow-xl"
          >
            Get Free Quotes
          </button>
          
          <p className="text-xs text-gray-500 text-center">
            By proceeding, you agree to our Terms & Conditions and Privacy Policy
          </p>
        </form>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-white shadow-sm sticky top-0 z-40 border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <div className="text-2xl font-bold">
                <span className="text-teal-500">Go</span>
                <span className="text-blue-600">Cover</span>
              </div>
            </div>
            
            <nav className="hidden md:flex space-x-8">
              <a href="#" className="text-gray-700 hover:text-teal-600 transition-colors font-medium">Health Insurance</a>
              <a href="#" className="text-gray-700 hover:text-teal-600 transition-colors font-medium">Motor Insurance</a>
              <a href="#" className="text-gray-700 hover:text-teal-600 transition-colors font-medium">Life Insurance</a>
              <a href="#" className="text-gray-700 hover:text-teal-600 transition-colors font-medium">Home Insurance</a>
              <a href="#" className="text-gray-700 hover:text-teal-600 transition-colors font-medium">Claims</a>
            </nav>
            
            <div className="hidden md:flex items-center space-x-4">
              <button className="text-gray-700 hover:text-teal-600 transition-colors font-medium">Login</button>
              <button className="bg-gradient-to-r from-teal-500 to-blue-600 text-white px-6 py-2 rounded-lg hover:from-teal-600 hover:to-blue-700 transition-all font-medium shadow-md">
                Sign Up
              </button>
            </div>
            
            <button
              className="md:hidden p-2"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
        
        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden bg-white border-t border-gray-100">
            <div className="px-4 py-2 space-y-1">
              <a href="#" className="block px-3 py-2 text-gray-700 hover:text-teal-600 hover:bg-gray-50 rounded-lg">Health Insurance</a>
              <a href="#" className="block px-3 py-2 text-gray-700 hover:text-teal-600 hover:bg-gray-50 rounded-lg">Motor Insurance</a>
              <a href="#" className="block px-3 py-2 text-gray-700 hover:text-teal-600 hover:bg-gray-50 rounded-lg">Life Insurance</a>
              <a href="#" className="block px-3 py-2 text-gray-700 hover:text-teal-600 hover:bg-gray-50 rounded-lg">Home Insurance</a>
              <a href="#" className="block px-3 py-2 text-gray-700 hover:text-teal-600 hover:bg-gray-50 rounded-lg">Claims</a>
            </div>
          </div>
        )}
      </header>

      {/* Hero Section */}
      <section className="bg-gradient-to-br from-gray-50 via-white to-teal-50 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <div className="inline-flex items-center bg-teal-50 text-teal-700 px-4 py-2 rounded-full text-sm font-medium mb-6">
              <Star className="w-4 h-4 mr-2 fill-current" />
              Trusted by 50L+ Indians
            </div>
            
            <h1 className="text-5xl md:text-6xl font-bold text-gray-900 mb-6 leading-tight">
              India's Leading
              <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-teal-500 to-blue-600">Insurance Platform</span>
            </h1>
            
            <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-12 leading-relaxed">
              Compare insurance plans from 45+ top insurers and save up to 85% on premiums. 
              Get instant quotes, expert advice, and hassle-free claims support.
            </p>
            
            <div className="flex flex-wrap justify-center gap-3 mb-12">
              {insuranceTypes.map((type) => {
                const Icon = type.icon;
                return (
                  <button
                    key={type.id}
                    onClick={() => setSelectedInsurance(type.id)}
                    className={`flex items-center px-6 py-3 rounded-2xl font-medium transition-all duration-300 transform hover:scale-105 ${
                      selectedInsurance === type.id
                        ? `bg-gradient-to-r ${type.color} text-white shadow-lg shadow-teal-500/25`
                        : 'bg-white text-gray-700 hover:bg-gray-50 shadow-md border border-gray-200'
                    }`}
                  >
                    <Icon size={20} className="mr-2" />
                    {type.name}
                  </button>
                );
              })}
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <button
                onClick={() => setShowQuoteForm(true)}
                className="bg-gradient-to-r from-teal-500 to-blue-600 text-white px-8 py-4 rounded-2xl font-semibold text-lg hover:from-teal-600 hover:to-blue-700 transform hover:scale-105 transition-all duration-200 shadow-lg hover:shadow-xl inline-flex items-center"
              >
                Get Free Quotes
                <ArrowRight size={20} className="ml-2" />
              </button>
              
              <div className="flex items-center text-gray-600">
                <Clock size={16} className="mr-2" />
                <span className="text-sm">Takes less than 2 minutes</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Trust Indicators */}
      <section className="py-16 bg-white border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            <div className="text-center group">
              <div className="text-4xl font-bold text-teal-600 mb-2 group-hover:scale-110 transition-transform">50L+</div>
              <div className="text-gray-600 font-medium">Happy Customers</div>
            </div>
            <div className="text-center group">
              <div className="text-4xl font-bold text-blue-600 mb-2 group-hover:scale-110 transition-transform">45+</div>
              <div className="text-gray-600 font-medium">Insurance Partners</div>
            </div>
            <div className="text-center group">
              <div className="text-4xl font-bold text-teal-600 mb-2 group-hover:scale-110 transition-transform">₹1000Cr+</div>
              <div className="text-gray-600 font-medium">Claims Settled</div>
            </div>
            <div className="text-center group">
              <div className="text-4xl font-bold text-blue-600 mb-2 group-hover:scale-110 transition-transform">4.8★</div>
              <div className="text-gray-600 font-medium">Customer Rating</div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Why Choose GoCover?
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Experience the future of insurance with our innovative platform
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <div key={index} className="bg-white p-8 rounded-2xl shadow-sm hover:shadow-lg transition-all duration-300 group border border-gray-100">
                  <div className="bg-gradient-to-r from-teal-500 to-blue-600 w-14 h-14 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                    <Icon className="h-7 w-7 text-white" />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-3">{feature.title}</h3>
                  <p className="text-gray-600 leading-relaxed">{feature.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Insurance Plans Comparison */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Popular Health Insurance Plans
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Compare and choose from our top-rated health insurance plans
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            {healthPlans.map((plan) => (
              <div
                key={plan.id}
                className={`bg-white rounded-3xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:scale-[1.02] relative border ${
                  plan.popular ? 'border-teal-200 ring-2 ring-teal-500/20' : 'border-gray-200'
                }`}
              >
                {plan.popular && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <span className="bg-gradient-to-r from-teal-500 to-blue-600 text-white px-6 py-2 rounded-full text-sm font-semibold shadow-lg">
                      Most Popular
                    </span>
                  </div>
                )}
                
                <div className="absolute top-6 right-6">
                  <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-sm font-semibold">
                    {plan.discount}
                  </span>
                </div>
                
                <div className="mb-6">
                  <h3 className="text-2xl font-bold text-gray-900 mb-2">{plan.name}</h3>
                  <p className="text-gray-600 mb-4">{plan.provider}</p>
                  <div className="flex items-center mb-4">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        size={16}
                        className={`${
                          i < Math.floor(plan.rating) ? 'text-yellow-400 fill-current' : 'text-gray-300'
                        }`}
                      />
                    ))}
                    <span className="ml-2 text-sm text-gray-600 font-medium">({plan.rating})</span>
                  </div>
                </div>
                
                <div className="mb-8">
                  <div className="flex items-baseline mb-2">
                    <span className="text-3xl font-bold text-teal-600">{plan.premium}</span>
                    <span className="text-gray-500 ml-2">/year</span>
                  </div>
                  <div className="text-lg font-semibold text-gray-900">
                    Coverage: {plan.coverage}
                  </div>
                </div>
                
                <div className="space-y-3 mb-8">
                  {plan.features.map((feature, index) => (
                    <div key={index} className="flex items-center">
                      <CheckCircle size={16} className="text-teal-500 mr-3 flex-shrink-0" />
                      <span className="text-gray-700">{feature}</span>
                    </div>
                  ))}
                </div>
                
                <button className="w-full bg-gradient-to-r from-teal-500 to-blue-600 text-white py-3 px-6 rounded-xl font-semibold hover:from-teal-600 hover:to-blue-700 transition-all transform hover:scale-[1.02] shadow-md">
                  View Details & Buy
                </button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              What Our Customers Say
            </h2>
            <p className="text-xl text-gray-600">
              Join millions of satisfied customers who trust GoCover
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <div key={index} className="bg-white rounded-3xl p-8 shadow-lg hover:shadow-xl transition-all duration-300 border border-gray-100">
                <div className="flex items-center mb-6">
                  <img
                    src={testimonial.avatar}
                    alt={testimonial.name}
                    className="w-14 h-14 rounded-full mr-4 object-cover"
                  />
                  <div>
                    <h4 className="font-semibold text-gray-900 text-lg">{testimonial.name}</h4>
                    <p className="text-gray-600">{testimonial.location}</p>
                    <p className="text-teal-600 text-sm font-medium">{testimonial.plan}</p>
                  </div>
                </div>
                
                <div className="flex mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      size={16}
                      className={`${
                        i < testimonial.rating ? 'text-yellow-400 fill-current' : 'text-gray-300'
                      }`}
                    />
                  ))}
                </div>
                
                <p className="text-gray-700 leading-relaxed italic">"{testimonial.text}"</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-teal-500 to-blue-600 relative overflow-hidden">
        <div className="absolute inset-0 bg-black opacity-10"></div>
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8 relative z-10">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            Ready to Get Started?
          </h2>
          <p className="text-xl text-teal-100 mb-8 leading-relaxed">
            Compare insurance plans from 45+ providers and find the perfect coverage for you and your family. 
            Get instant quotes and save up to 85% on premiums.
          </p>
          <button
            onClick={() => setShowQuoteForm(true)}
            className="bg-white text-teal-600 px-8 py-4 rounded-2xl font-semibold text-lg hover:bg-gray-50 transform hover:scale-105 transition-all duration-200 shadow-lg hover:shadow-xl inline-flex items-center"
          >
            Get Free Quotes Now
            <ArrowRight size={20} className="ml-2" />
          </button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8 mb-12">
            <div>
              <div className="text-2xl font-bold mb-6">
                <span className="text-teal-400">Go</span>
                <span className="text-blue-400">Cover</span>
              </div>
              <p className="text-gray-400 mb-6 leading-relaxed">
                Your trusted partner for comprehensive insurance solutions. Compare, choose, and save with confidence.
              </p>
              <div className="flex space-x-4">
                <div className="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center hover:bg-teal-600 transition-colors cursor-pointer">
                  <span className="text-sm font-bold">f</span>
                </div>
                <div className="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center hover:bg-teal-600 transition-colors cursor-pointer">
                  <span className="text-sm font-bold">t</span>
                </div>
                <div className="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center hover:bg-teal-600 transition-colors cursor-pointer">
                  <span className="text-sm font-bold">in</span>
                </div>
              </div>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold mb-6">Insurance Types</h3>
              <ul className="space-y-3">
                <li><a href="#" className="text-gray-400 hover:text-teal-400 transition-colors">Health Insurance</a></li>
                <li><a href="#" className="text-gray-400 hover:text-teal-400 transition-colors">Motor Insurance</a></li>
                <li><a href="#" className="text-gray-400 hover:text-teal-400 transition-colors">Life Insurance</a></li>
                <li><a href="#" className="text-gray-400 hover:text-teal-400 transition-colors">Home Insurance</a></li>
                <li><a href="#" className="text-gray-400 hover:text-teal-400 transition-colors">Travel Insurance</a></li>
              </ul>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold mb-6">Company</h3>
              <ul className="space-y-3">
                <li><a href="#" className="text-gray-400 hover:text-teal-400 transition-colors">About Us</a></li>
                <li><a href="#" className="text-gray-400 hover:text-teal-400 transition-colors">Claims Process</a></li>
                <li><a href="#" className="text-gray-400 hover:text-teal-400 transition-colors">Customer Reviews</a></li>
                <li><a href="#" className="text-gray-400 hover:text-teal-400 transition-colors">Careers</a></li>
                <li><a href="#" className="text-gray-400 hover:text-teal-400 transition-colors">Media Kit</a></li>
              </ul>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold mb-6">Contact</h3>
              <div className="space-y-4">
                <div className="flex items-center">
                  <Phone size={16} className="text-teal-400 mr-3" />
                  <span className="text-gray-400">1800-123-4567</span>
                </div>
                <div className="flex items-center">
                  <Mail size={16} className="text-teal-400 mr-3" />
                  <span className="text-gray-400">hello@gocover.com</span>
                </div>
                <div className="flex items-start">
                  <MapPin size={16} className="text-teal-400 mr-3 mt-1" />
                  <span className="text-gray-400">
                    123 Insurance Street<br />
                    Mumbai, Maharashtra 400001
                  </span>
                </div>
              </div>
            </div>
          </div>
          
          <div className="border-t border-gray-800 pt-8 text-center">
            <p className="text-gray-400">
              © 2024 GoCover. All rights reserved. | Privacy Policy | Terms of Service | Sitemap
            </p>
          </div>
        </div>
      </footer>

      {/* Quote Form Modal */}
      {showQuoteForm && <QuoteForm />}
    </div>
  );
}

export default App;